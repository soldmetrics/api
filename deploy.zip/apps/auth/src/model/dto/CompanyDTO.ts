export class CompanyDTO {
  name: string;
}
