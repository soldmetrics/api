export const SALES_IMPORT_SERVICE = 'SALES_IMPORT';
export const AUTH_SERVICE = 'AUTH';

export const MARKETPLACES = ['MercadoLivre', 'Shopee'];
